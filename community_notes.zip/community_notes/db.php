<?php
include 'config.php';
echo "Koneksi ke database berhasil!";
?>